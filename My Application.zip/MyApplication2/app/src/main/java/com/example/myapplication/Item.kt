package com.example.myapplication

data class Item (val num: Int, val title: String, val image: String, val time:Long)