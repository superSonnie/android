package com.example.myapplication
//아웃풋
data class Register(
    var code: String,
    var msg: String
)